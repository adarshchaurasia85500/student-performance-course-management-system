# Student-Performance-Course-Management-System
Student Performance &amp; Course Management System, this is tested in mysqlworkbench
